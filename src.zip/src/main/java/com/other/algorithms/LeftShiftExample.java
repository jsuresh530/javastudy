/**
 * 
 */
package com.other.algorithms;


/**
 * @author sjonnalagadda
 *
 */
public class LeftShiftExample
{
	public static void main(String[] args)
	{
		System.err.println("Value : "+(2 << 11)); //1073741824 
	}
}
