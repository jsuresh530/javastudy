package com.other.algorithms;

public class ReadUrl {

	public static void main(String[] args) {
		// TODO Auto-generated method stubzzzzzzzzzz
		
	System.out.println(System.getProperty("user.name"));
	}

}
