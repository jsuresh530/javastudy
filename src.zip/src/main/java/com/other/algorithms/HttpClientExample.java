/**
 * 
 */
package com.other.algorithms;


/**
 * @author sjonnalagadda
 *
 */
public class HttpClientExample
{

	/**
	 * @param args
	 */
	public static void main(String[] args)
	{
		
	}
}
