package com.other.algorithms;

public class MultiMap
{

	/*public static void main(String[] args)
	{
		multiMapExample();
		apacheMultiMap();
	}

	private static void apacheMultiMap()
	{
        // create multimap to store key and values

        MultiValueMap multiMap = new MultiValueMap();

        // put values into map for A

        multiMap.put("A", "Apple");

        multiMap.put("A", "Aeroplane");

        // put values into map for B

        multiMap.put("B", "Bat");

        multiMap.put("B", "Banana");

        // put values into map for C

        multiMap.put("C", "Cat");

        multiMap.put("C", "Car");

        // retrieve and display values

        System.out.println("Fetching Keys and corresponding [Multiple] Values n");

        // get all the set of keys

        Set<String> keys = multiMap.keySet();

        // iterate through the key set and display key and values

        for (String key : keys) {

            System.out.println("Key = " + key);

            System.out.println("Values = " + multiMap.get(key) + "n");

        }
	}

	private static void multiMapExample()
	{
		Map<String, List<String>> map = new HashMap<String, List<String>>();

		List<String> list = new ArrayList<>();
		list.add("suresh");
		list.add("babu");
		
		List<String> list1 = new ArrayList<>();
		list1.add("harresg");
		list1.add("babu");
		
		
		map.put("A", list);
		map.put("B", list1);
		
		for (Entry<String, List<String>> entry : map.entrySet())
		{
			System.out.println(entry.getKey()+" ---------> "+entry.getValue());
		}
		
		for (String key : map.keySet())
		{
			System.out.println(key+" ---------> "+map.get(key));
		}
		
	}
*/
}
