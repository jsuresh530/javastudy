package com.other.algorithms;


public class BinarySearch
{

	public static void main(String[] args)
	{
	}
}
