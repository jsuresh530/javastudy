/**
 * 
 */
package com.other.talent;


/**
 * @author sjonnalagadda
 *
 */
public class Anargarm
{

	/**
	 * @param args
	 */
	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
	}
}
