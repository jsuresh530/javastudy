package com.coreexamples.CoreJava.examples;
public class Alphabetes_AtoZ_aTOz {
	public static void main(String[] args) {
		char cc = 'A';
		System.out.println("A to Z...");
		for (char i = 65; i <= 90; i++) {
			System.out.println(i);
		}
		System.out.println("a To z...");
		for (char i = 97; i <= 122; i++) {
			System.out.println(i);
		}
	}
}

