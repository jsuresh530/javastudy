package com.coreexamples.CoreJava.examples;

public class Fourth {
	public static void main(String[] args) {
		int a = 1;
		final int b = 20;
		while (a <= 10) {
			System.out.println("Hello...");
			a++;
		}

	}
}
