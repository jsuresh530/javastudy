package com.coreexamples.CoreJava.examples;
public class Sixth {
public static void main(String[] args) {
	int a=10;
	if(a<=0){
		if(a==0){
			System.out.println("1");
		}
		else{
			System.out.println("2");
		}
	}
	else{
		System.out.println("3");
	}
}
}
