package com.multithreads.chopstick;

public class Constants {
    private Constants(){

    }
    //diNING philosophers problem
    public static final int NUM_OF_PHILOSOPHERS=5;
    public static final int NUM_OF_CHOPSTICKS=5;
    public static final int SIMULATION_RUNNING_TIME=5*1000;


}
