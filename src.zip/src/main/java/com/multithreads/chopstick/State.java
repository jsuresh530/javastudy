package com.multithreads.chopstick;

public enum State {
    LEFT, RIGHT;
}
