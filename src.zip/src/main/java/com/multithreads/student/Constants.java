package com.multithreads.student;

public class Constants {
    private Constants(){

    }

    public static final int NUM_OF_STUDENTS = 5;
    public static final int NUM_OF_BOOKS = 7;

}
