package com.solid.principles.liskov;

public interface Shape {

    public int computeArea();
}
